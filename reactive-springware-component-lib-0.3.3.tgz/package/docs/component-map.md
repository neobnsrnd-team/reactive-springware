# Component Map — Figma → React 매핑 전략

> **대상 Figma 파일**: Hana Bank App (`eRnV2DPVtHbGn5HSISS65O`)
> **작성 기준**: 기존 코드베이스(`packages/@shared/components`) 분석 + theme.json v2.0.0
> **패키지 네임스페이스**: `@reactive-springware/component-lib`
> **최종 수정**: 2026-03-26

---

## 목차

1. [Mapping Strategy 개요](#1-mapping-strategy-개요)
2. [디자인 토큰 → React Props 매핑 규칙](#2-디자인-토큰--react-props-매핑-규칙)
3. [레이아웃 요소 표준 처리 지침](#3-레이아웃-요소-표준-처리-지침)
4. [컴포넌트 계층 구조 및 네이밍 컨벤션](#4-컴포넌트-계층-구조-및-네이밍-컨벤션)
5. [주요 컴포넌트 TypeScript Interface 초안](#5-주요-컴포넌트-typescript-interface-초안)
6. [확정된 도메인 설계 방침](#6-확정된-도메인-설계-방침)

---

## 1. Mapping Strategy 개요

### 1.1 매핑 원칙

| 원칙 | 설명 |
|------|------|
| **1:1 컴포넌트 매핑** | Figma의 Component/Variant 1개 = React 컴포넌트 1개 |
| **토큰 우선** | 하드코딩 금지. 모든 색상·간격·타이포는 CSS 변수(`var(--*)`) 또는 Tailwind 토큰 클래스 사용 |
| **브랜드 중립** | 컴포넌트는 은행별 브랜드를 알지 못함. `data-brand` 속성으로 외부에서 주입 |
| **Variant → prop** | Figma Variant 옵션 = TypeScript Union 타입의 prop으로 1:1 변환 |
| **Auto Layout → Flex/Grid** | Figma Auto Layout = Stack / Inline / Grid 컴포넌트로 대응 |

### 1.2 매핑 결정 흐름

```
Figma 레이어 확인
      │
      ├─ Component Set (Variant 존재)?  ──→  React 컴포넌트 (variant prop)
      │
      ├─ Frame + Auto Layout만?  ──────────→  Stack / Inline / Grid 유틸 컴포넌트
      │
      ├─ 반복 패턴(List 구조)?  ──────────→  ListItem + map()
      │
      ├─ 화면 전체 프레임?  ────────────→  PageLayout / HomePageLayout / BlankPageLayout
      │
      └─ 1회성 장식 요소?  ─────────────→  인라인 JSX (컴포넌트화 하지 않음)
```

### 1.3 Figma 페이지 구조 → 컴포넌트 분류

Hana Bank App 기준으로 식별된 화면 유형:

| Figma 화면 유형 | layoutType | 사용 레이아웃 컴포넌트 |
|----------------|-----------|----------------------|
| 홈/메인 대시보드 | `home` | `HomePageLayout` |
| 계좌 목록·상세 | `page` | `PageLayout` |
| 로그인·온보딩 | `no-header` | `BlankPageLayout` |
| 이체·폼 화면 | `page` | `PageLayout` |

---

## 2. 디자인 토큰 → React Props 매핑 규칙

### 2.1 Color 토큰 매핑

#### 브랜드 컬러 (은행별 가변)

Figma에서 `Primary / Brand` 계열 색상은 CSS 변수로 처리. **컴포넌트 prop에 색상 값을 직접 전달하지 않는다.**

| Figma 색상 역할 | CSS 변수 | Tailwind 클래스 | prop 노출 여부 |
|---------------|----------|----------------|--------------|
| 브랜드 메인 | `--bank-brand` | `bg-brand`, `text-brand` | ❌ (토큰 고정) |
| 브랜드 대안 | `--bank-brand-alt` | `text-brand-alt` | ❌ |
| 브랜드 전경색 | `--bank-brand-fg` | `text-brand-fg` | ❌ |
| 브랜드 5% 투명도 | `--bank-brand-5` | `bg-brand-5` | ❌ |
| 브랜드 그림자 | `--bank-brand-shadow` | `shadow-brand` | ❌ |

#### 시맨틱 컬러 (공통 고정)

| Figma 색상 역할 | CSS 변수 | Tailwind 클래스 | prop 예시 |
|---------------|----------|----------------|---------|
| 위험/에러 | `--color-danger` | `text-danger`, `bg-danger-surface` | `variant="danger"` |
| 성공 | `--color-success` | `text-success`, `bg-success-surface` | `variant="success"` |
| 경고 | `--color-warning` | `text-warning-text` | `variant="warning"` |
| 텍스트 헤딩 | `--color-text-heading` | `text-text-heading` | — |
| 텍스트 보조 | `--color-text-muted` | `text-text-muted` | — |
| 서피스 기본 | `--color-surface` | `bg-surface` | — |
| 테두리 기본 | `--color-border` | `border-border` | — |

#### 매핑 규칙 요약

```
Figma 색상 → 용도 파악 → 브랜드 가변? → CSS 변수 클래스 사용 (prop 미노출)
                        ↓ 아니오
                      시맨틱? → variant prop ('success' | 'danger' | 'warning')
                        ↓ 아니오
                      고정값 → 해당 Tailwind 유틸 클래스 직접 사용
```

### 2.2 Typography 토큰 매핑

#### 폰트 패밀리

| Figma 폰트 | 적용 대상 | Tailwind 클래스 |
|-----------|---------|----------------|
| Noto Sans KR | 일반 텍스트 | `font-sans` (기본값, 별도 지정 불필요) |
| Manrope | 금액·숫자 | `font-numeric` |
| Material Symbols | 아이콘 | `font-icon` |

#### 폰트 사이즈 → prop 변환

Text 컴포넌트의 `variant` prop 기준:

| Figma 텍스트 스타일 | px | Tailwind | `variant` prop 값 |
|-------------------|-----|----------|-----------------|
| Heading / Title | 24px | `text-2xl` | `heading` |
| Subheading | 20px | `text-xl` | `subheading` |
| Body Large | 18px | `text-lg` | `body-lg` |
| Body Base | 16px | `text-base` | `body` |
| Body Small | 14px | `text-sm` | `body-sm` |
| Caption | 12px | `text-xs` | `caption` |

#### 폰트 웨이트

| Figma 스타일 | font-weight | Tailwind |
|------------|------------|---------|
| Regular | 400 | `font-normal` |
| Medium | 500 | `font-medium` |
| Bold | 700 | `font-bold` |

### 2.3 Spacing 토큰 매핑

Figma Auto Layout의 `gap` / `padding` 값을 theme.json 스케일에 매핑:

| Figma 값 | 토큰명 | Tailwind | prop/className |
|---------|--------|---------|---------------|
| 4px | `xs` | `gap-xs`, `p-xs` | `gap="xs"` (Stack/Grid) |
| 8px | `sm` | `gap-sm`, `p-sm` | `gap="sm"` |
| 12px | `md` | `gap-md`, `p-md` | `gap="md"` |
| 16px | `standard` | `gap-standard`, `p-standard` | `gap="lg"` (Stack에서는 `lg`로 매핑 주의) |
| 20px | `lg` | `gap-lg`, `p-lg` | `gap="lg"` |
| 24px | `xl` | `gap-xl`, `p-xl` | `gap="xl"` |
| 32px | `2xl` | `gap-2xl`, `p-2xl` | `gap="2xl"` |

> **주의**: Figma에서 `16px` gap이 나오면 Tailwind `gap-standard`(=`p-standard`)이지만,
> Stack/Inline의 `gap` prop 스케일에는 `standard` 키가 없으므로 `className="gap-standard"`으로 처리.

### 2.4 Border Radius 토큰 매핑

| Figma 값 | 토큰명 | Tailwind |
|---------|--------|---------|
| 4px | `xs` | `rounded-xs` |
| 8px | `sm` | `rounded-sm` (= `rounded-lg` Tailwind 기본과 혼동 주의) |
| 12px | `md` | `rounded-md` (= `rounded-xl` Tailwind 기본) |
| 16px | `lg` | `rounded-lg` (= `rounded-2xl` Tailwind 기본) |
| 24px | `xl` | `rounded-xl` |
| 9999px | `full` | `rounded-full` |

> **혼동 방지**: 이 프로젝트의 `rounded-*`는 theme.json 커스텀 스케일로 Tailwind 기본값과 다름.
> 반드시 `theme.json common.borderRadius` 기준으로 적용.

---

## 3. 레이아웃 요소 표준 처리 지침

### 3.1 컴포넌트화 기준

```
Figma 레이아웃 요소
        │
        ├─ 3개 이상 화면에서 동일 구조 반복?  ──→  컴포넌트화 (biz/ 또는 modules/)
        │
        ├─ 순수 간격·정렬만 담당?  ─────────→  Stack / Inline / Grid 조합
        │
        ├─ 단일 화면 전용 섹션?  ────────→  페이지 내 인라인 JSX (<section>, <div>)
        │
        └─ 텍스트+아이콘 단순 조합?  ────→  인라인 JSX (컴포넌트화 하지 않음)
```

### 3.2 모호한 레이아웃 요소별 처리 지침

#### A. 섹션 헤더 (타이틀 + 우측 링크)

```
Figma: [제목 텍스트]  [전체보기 →]
```

- **처리**: `Inline` 컴포넌트로 래핑, `justify="between"` 적용
- **컴포넌트화 기준**: 3곳 이상 반복 시 `SectionHeader` 모듈 컴포넌트로 추출

```tsx
// 인라인 처리 (반복 2회 이하)
<Inline justify="between" align="center" className="mb-md">
  <Text variant="subheading">최근 거래</Text>
  <button className="text-xs text-brand-text">전체보기</button>
</Inline>

// 컴포넌트화 (반복 3회 이상) → modules/SectionHeader.tsx 생성
<SectionHeader title="최근 거래" actionLabel="전체보기" onAction={...} />
```

#### B. 구분선(Divider)

```
Figma: ──────────────────
```

- **처리**: `<hr className="border-border-subtle my-sm" />` 인라인 사용
- **컴포넌트화 금지**: 단순 HR 요소는 컴포넌트로 만들지 않음

#### C. 빈 여백 섹션 (Spacer)

```
Figma: 명시적 높이를 가진 빈 Frame
```

- **처리**: Tailwind `h-*` 또는 `py-*` 클래스로 인라인 처리
- **예외**: `pb-nav`(80px 바텀 네비 여백)는 레이아웃 컴포넌트가 자동 처리

#### D. 배경 색상 섹션

```
Figma: 배경이 다른 색상인 컨테이너 Frame
```

- **처리**: `bg-surface-subtle`, `bg-brand-5` 등 시맨틱 토큰 클래스 적용
- **하드코딩 금지**: `bg-[#f5f8f8]` 같은 직접 색상값 사용 금지

#### E. 카드 내부 행(Row) 패턴

```
Figma: [레이블]  [값]
       [레이블]  [값]
```

- **처리**: `CardRow` 서브 컴포넌트 사용
- **단독 행**: `Inline justify="between"` 인라인 처리 허용

#### F. 아이콘 + 텍스트 조합

```
Figma: [아이콘] [텍스트]
```

- **처리**: `Inline gap="sm" align="center"` 인라인 래핑
- **컴포넌트화 기준**: 아이콘+텍스트 패턴이 인터랙션(클릭)을 가질 경우 `ListItem` 재사용

#### G. 그라데이션 배너

```
Figma: 브랜드 그라데이션 배경의 프로모션 배너
```

- **처리**: `BrandBanner variant="promo"` 사용
- **커스텀 배너**: 구조가 크게 다를 경우만 신규 컴포넌트 생성

#### H. 탭 네비게이션

```
Figma: [탭1] [탭2] [탭3]  (선택된 탭 하단 인디케이터)
```

- **처리**: `Tab` 컴포넌트 사용 (`variant="underline"` 또는 `"pill"`)
- **바텀 글로벌 탭**: `BrandBottomNav` 컴포넌트 사용 (커스텀 금지)

### 3.3 레이아웃 컴포넌트 선택 기준표

| 상황 | 사용 컴포넌트 |
|-----|------------|
| 세로 나열 (리스트, 폼 필드) | `Stack gap="md"` |
| 가로 나열 (버튼 행, 배지 그룹) | `Inline gap="sm"` |
| 좌우 분리 (레이블-값, 타이틀-액션) | `Inline justify="between"` |
| 2열 그리드 (퀵메뉴, 통계 카드) | `Grid cols={2} gap="sm"` |
| 전체 페이지 래퍼 | `PageLayout` / `HomePageLayout` / `BlankPageLayout` |
| 최대 너비 제한 컨테이너 | `Container` |

---

## 4. 컴포넌트 계층 구조 및 네이밍 컨벤션

### 4.1 패키지 네임스페이스 규칙

```
@reactive-springware/component-lib
├── core/        → 원자(Atom) 컴포넌트
├── modules/     → 분자(Molecule) 컴포넌트
├── biz/         → 도메인 특화 컴포넌트
└── layout/      → 레이아웃 컴포넌트
```

### 4.2 컴포넌트 네이밍 규칙

| 규칙 | 예시 |
|-----|-----|
| PascalCase | `AccountCard`, `TransferForm` |
| 도메인 접두사 금지 (core/modules) | ~~`BankingButton`~~ → `Button` |
| 도메인 접두사 허용 (biz/) | `BrandBanner`, `SearchAccordion` |
| 서브 컴포넌트: 부모명 + 역할 | `Card`, `CardHeader`, `CardRow` |
| 훅: `use` + 동사 | `useModal`, `useBankTheme` |

### 4.3 Props 네이밍 규칙

| 패턴 | 규칙 | 예시 |
|-----|-----|-----|
| 외형 변형 | `variant` | `variant="primary"` |
| 크기 | `size` | `size="md"` |
| 상태 | boolean prop (접두사 없음) | `loading`, `disabled`, `fullWidth` |
| 이벤트 | `on` + PascalCase | `onClick`, `onClose`, `onChange` |
| 자식 슬롯 | 역할명 | `leftIcon`, `rightIcon`, `action` |
| 렌더링 태그 | `as` | `as="section"` |

### 4.4 Figma Variants → React Props 구조 도출 규칙

#### 기본 원칙

Figma Component Set의 **Variant 속성명**은 다음 규칙으로 React prop 이름과 타입으로 변환한다.

| Figma Variant 속성 패턴 | → React prop | 타입 형태 |
|------------------------|-------------|---------|
| `Type` / `Variant` / `Style` | `variant` | `'primary' \| 'outline' \| ...` |
| `Size` | `size` | `'sm' \| 'md' \| 'lg'` |
| `State` | 분리 (아래 참조) | boolean 또는 union |
| `Has Icon` / `Icon` | `leftIcon?`, `rightIcon?` | `React.ReactNode` |
| `Full Width` | `fullWidth?` | `boolean` |
| `Direction` / `Orientation` | `direction?` | `'horizontal' \| 'vertical'` |

#### `State` 속성 처리 규칙

Figma의 `State` variant는 성격에 따라 prop 형태를 다르게 결정한다.

| Figma State 값 | → React 변환 | 이유 |
|---------------|-------------|-----|
| `Default` | (기본값, prop 불필요) | 명시 불필요 |
| `Hover` / `Active` / `Focus` | CSS pseudo-class | JS prop화 금지 — CSS로 처리 |
| `Disabled` | `disabled?: boolean` | HTML 표준 속성 상속 |
| `Loading` | `loading?: boolean` | 비동기 UX 전용 prop |
| `Error` / `Success` / `Warning` | `state?: 'error' \| 'success' \| 'warning'` | 유효성 검사 상태 묶음 |
| `Empty` / `Filled` | 내부 파생 상태 (prop 노출 안 함) | value 유무로 자동 결정 |
| `Checked` / `Selected` | `checked?: boolean` / `selected?: boolean` | 제어 컴포넌트 패턴 |

#### Figma Variant 값 → prop Union 값 변환표

Figma의 영문 Variant 값은 **kebab-case 소문자**로 변환한다.

| Figma Variant 값 | → `variant` prop 값 |
|-----------------|-------------------|
| `Primary` / `Filled` | `'primary'` |
| `Secondary` / `Outlined` / `Stroke` | `'outline'` |
| `Tertiary` / `Ghost` / `Text` | `'ghost'` |
| `Destructive` / `Error` | `'danger'` |
| `Promo` / `Brand` | `'promo'` |
| `Info` / `Neutral` | `'info'` |
| `Success` | `'success'` |
| `Warning` | `'warning'` |

#### 크기 Variant 표준화

| Figma Size 값 | → `size` prop 값 |
|--------------|----------------|
| `XSmall` / `XS` | `'xs'` (필요 시) |
| `Small` / `S` | `'sm'` |
| `Medium` / `M` / `Default` | `'md'` |
| `Large` / `L` | `'lg'` |
| `XLarge` / `XL` | `'xl'` (필요 시) |

#### Storybook `title` 경로 네이밍 규칙

스토리 `title`은 `카테고리/컴포넌트명` 형식. Figma 패널 구조와 1:1 대응되도록 설계.

| 카테고리 | title 패턴 | 예시 |
|---------|-----------|-----|
| core/ | `'Core/컴포넌트명'` | `'Core/Button'` |
| modules/ | `'Modules/컴포넌트명'` | `'Modules/Modal'` |
| biz/ | `'Biz/컴포넌트명'` | `'Biz/AccountSummaryCard'` |
| layout/ | `'Layout/컴포넌트명'` | `'Layout/Stack'` |

Story 이름(export 변수명)은 Figma Variant 값 또는 사용 시나리오를 **PascalCase**로 표현:

```typescript
// ✅ 올바른 Story 이름 예시
export const Primary: Story = {};          // Figma "Primary" variant
export const Outline: Story = {};          // Figma "Outlined" variant
export const Sizes: Story = {};            // 크기 비교
export const Loading: Story = {};          // 상태 시나리오
export const WithIcons: Story = {};        // 슬롯 활용 시나리오
export const Controlled: Story = {};       // 인터랙션 시나리오 (useState 포함)

// ❌ 금지
export const story1: Story = {};           // 의미 없는 이름
export const ButtonPrimary: Story = {};    // 컴포넌트명 중복 — title에 이미 포함됨
```

### 4.5 컴포넌트 분류 기준

```
core/    → 단일 HTML 요소 수준. 자체 상태 없음.
           예: Button, Input, Badge, Avatar, Text, Spinner

modules/ → 2개 이상 core 조합. 도메인 무관.
           예: Card, ListItem, Modal, DatePicker, Pagination

biz/     → 금융 도메인 특화. 브랜드 컨텍스트 의존 가능.
           예: BrandBanner, SearchAccordion, AccountSummaryCard

layout/  → 페이지 전체 구조 담당.
           예: PageLayout, HomePageLayout, Stack, Grid
```

---

## 5. 주요 컴포넌트 TypeScript Interface 초안

> **네이밍**: `@reactive-springware/component-lib` 기준으로 제안.
> 현재 코드베이스의 기존 타입과 호환성 유지.

### 5.1 Core 컴포넌트

```typescript
// ── Button ────────────────────────────────────────────────────
export type ButtonVariant = 'primary' | 'outline' | 'ghost' | 'danger';
export type ButtonSize    = 'sm' | 'md' | 'lg';
export type ButtonJustify = 'center' | 'between';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?:   ButtonVariant;   // 기본: 'primary'
  size?:      ButtonSize;      // 기본: 'md'
  loading?:   boolean;         // 로딩 스피너 + aria-busy 처리
  iconOnly?:  boolean;         // 정방형 아이콘 전용 버튼
  leftIcon?:  React.ReactNode;
  rightIcon?: React.ReactNode;
  fullWidth?: boolean;         // w-full
  justify?:   ButtonJustify;   // 내부 정렬. between: 아코디언 트리거 패턴
}

// ── Input ─────────────────────────────────────────────────────
export type InputSize            = 'md' | 'lg';
export type InputValidationState = 'default' | 'error' | 'success';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?:           string;
  helperText?:      string;             // 안내 문구 또는 에러 메시지
  validationState?: InputValidationState; // 기본: 'default'
  size?:            InputSize;
  leftIcon?:        React.ReactNode;
  rightElement?:    React.ReactNode;    // 우측 버튼 슬롯 (단위, 인증 등)
  fullWidth?:       boolean;
}

// ── Badge ─────────────────────────────────────────────────────
export type BadgeVariant = 'brand' | 'success' | 'danger' | 'warning' | 'neutral';

export interface BadgeProps {
  variant?:  BadgeVariant;  // 기본: 'neutral'
  children:  React.ReactNode;
  dot?:      boolean;       // 텍스트 없이 점(dot)만 표시
  className?: string;
}

// ── Text ──────────────────────────────────────────────────────
export type TextVariant = 'heading' | 'subheading' | 'body-lg' | 'body' | 'body-sm' | 'caption';
export type TextWeight  = 'normal' | 'medium' | 'bold';
export type TextColor   = 'heading' | 'base' | 'secondary' | 'muted' | 'brand' | 'danger' | 'success';

export interface TextProps {
  variant?:   TextVariant;  // 기본: 'body'
  weight?:    TextWeight;   // 기본: variant별 기본값
  color?:     TextColor;    // 기본: 'base'
  numeric?:   boolean;      // 금액 등 숫자 → font-numeric (Manrope)
  as?:        React.ElementType; // 기본: 'p'
  children:   React.ReactNode;
  className?: string;
}

// ── Avatar ────────────────────────────────────────────────────
export type AvatarSize = 'sm' | 'md' | 'lg' | 'xl';

export interface AvatarProps {
  src?:       string;       // 이미지 URL. 없으면 이니셜 표시
  alt?:       string;
  initials?:  string;       // 이미지 로드 실패 시 표시할 텍스트 (최대 2자)
  size?:      AvatarSize;   // 기본: 'md'
  className?: string;
}
```

### 5.2 Modules 컴포넌트

```typescript
// ── Card ──────────────────────────────────────────────────────
export interface CardProps {
  children:     React.ReactNode;
  interactive?: boolean;        // hover/active 인터랙션 활성화
  onClick?:     () => void;     // 전달 시 <button> 렌더링
  className?:   string;
}

export interface CardHeaderProps {
  title:      string;
  subtitle?:  string;
  action?:    React.ReactNode; // 우측 버튼/링크 슬롯
  icon?:      React.ReactNode; // 좌측 아이콘 슬롯
}

export interface CardRowProps {
  label:           string;
  value:           string;
  valueClassName?: string;     // 금액 강조 등 값 스타일 override
}

// ── AccountSummaryCard (신규 제안 — biz/) ─────────────────────
// Figma의 계좌 요약 카드 패턴 전용 컴포넌트
export interface AccountSummaryCardProps {
  bankName:        string;       // 예: '하나은행'
  accountName:     string;       // 예: '급여 통장'
  accountNumber:   string;       // 예: '123-456-789012'
  balance:         number;       // 원화 단위 숫자 (컴포넌트 내부에서 포맷)
  balanceLabel?:   string;       // 기본: '잔액'
  onClick?:        () => void;
  actions?:        React.ReactNode; // 이체·내역 버튼 슬롯
}

// ── ListItem ──────────────────────────────────────────────────
export interface ListItemProps {
  icon?:           React.ReactNode;
  title:           string;
  description?:    string;
  value?:          string;         // 우측 주요 값 (금액, 날짜 등)
  valueClassName?: string;
  badge?:          React.ReactNode;
  onClick?:        () => void;
  className?:      string;
}

// ── TransactionListItem (신규 제안 — biz/) ────────────────────
// Figma의 거래 내역 행 패턴 전용 컴포넌트
export type TransactionType = 'deposit' | 'withdrawal' | 'transfer';

export interface TransactionListItemProps {
  type:            TransactionType;
  title:           string;          // 거래처명 또는 적요
  date:            string;          // 표시용 날짜 문자열
  amount:          number;          // 원화 단위 숫자
  balance?:        number;          // 거래 후 잔액
  onClick?:        () => void;
}

// ── Modal ─────────────────────────────────────────────────────
export interface ModalProps {
  open:           boolean;
  onClose:        () => void;
  title?:         string;
  description?:   string;
  children?:      React.ReactNode;  // 본문 슬롯
  footer?:        React.ReactNode;  // 버튼 영역 슬롯
  /** 모달 외부 클릭 시 닫기 여부. 기본: true */
  closeOnOverlay?: boolean;
  size?:          'sm' | 'md' | 'lg'; // 기본: 'md'
}

// ── Pagination ────────────────────────────────────────────────
export interface PaginationProps {
  currentPage:   number;
  totalPages:    number;
  onPageChange:  (page: number) => void;
  /** 표시할 최대 페이지 버튼 수. 기본: 5 */
  maxVisible?:   number;
  className?:    string;
}

// ── DatePicker ────────────────────────────────────────────────
export type DatePickerMode = 'single' | 'range';

export interface DatePickerProps {
  mode?:        DatePickerMode;   // 기본: 'single'
  value?:       Date | null;
  rangeValue?:  [Date | null, Date | null]; // mode='range'일 때 사용
  onChange?:    (date: Date | null) => void;
  onRangeChange?: (range: [Date | null, Date | null]) => void;
  minDate?:     Date;
  maxDate?:     Date;
  placeholder?: string;
  label?:       string;
  disabled?:    boolean;
}
```

### 5.3 Layout 컴포넌트

```typescript
// ── PageLayout ────────────────────────────────────────────────
export interface PageLayoutProps extends React.HTMLAttributes<HTMLDivElement> {
  title:        string;
  onBack?:      () => void;         // 미전달 시 뒤로가기 버튼 숨김
  rightAction?: React.ReactNode;    // 헤더 우측 슬롯
  className?:   string;
}

// ── HomePageLayout ────────────────────────────────────────────
export interface HomePageLayoutProps extends React.HTMLAttributes<HTMLDivElement> {
  title:            string;
  logo?:            React.ReactNode;  // 타이틀 좌측 로고 슬롯
  rightAction?:     React.ReactNode;  // 미전달 시 기본 User·Bell·Menu 3버튼
  hasNotification?: boolean;          // 기본 벨 버튼 알림 뱃지 표시 여부 (기본: false)
  withBottomNav?:   boolean;          // 하단 탭바 여백 자동 추가 (기본: true)
  className?:       string;
}

// ── BlankPageLayout ───────────────────────────────────────────
export interface BlankPageLayoutProps extends React.HTMLAttributes<HTMLDivElement> {
  className?: string;
}

// ── Stack ─────────────────────────────────────────────────────
export type StackGap   = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
export type StackAlign = 'start' | 'center' | 'end' | 'stretch';

export interface StackProps {
  children:   React.ReactNode;
  gap?:       StackGap;        // 기본: 'md'
  align?:     StackAlign;
  as?:        React.ElementType;
  className?: string;
}

// ── Grid ──────────────────────────────────────────────────────
export interface GridProps {
  children:     React.ReactNode;
  cols?:        1 | 2 | 3 | 4;
  tabletCols?:  2 | 3 | 4;
  gap?:         StackGap;
  className?:   string;
}

// ── Inline ────────────────────────────────────────────────────
export type InlineAlign   = 'start' | 'center' | 'end' | 'baseline' | 'stretch';
export type InlineJustify = 'start' | 'center' | 'end' | 'between' | 'around' | 'evenly';

export interface InlineProps {
  children:   React.ReactNode;
  gap?:       StackGap;
  align?:     InlineAlign;
  justify?:   InlineJustify;
  wrap?:      boolean;
  as?:        React.ElementType;
  className?: string;
}
```

### 5.4 Biz 컴포넌트

```typescript
// ── BrandBanner ───────────────────────────────────────────────
export type BannerVariant = 'promo' | 'info' | 'warning';

export interface BannerProps {
  variant?:     BannerVariant;   // 기본: 'promo'
  title:        string;
  description?: string;
  action?:      React.ReactNode; // 우측 CTA 슬롯
  onClose?:     () => void;      // 전달 시 닫기 버튼 표시
  className?:   string;
}

// ── QuickMenuGrid (신규 제안 — biz/) ─────────────────────────
// Figma 홈 화면의 퀵메뉴(2×N 그리드) 패턴
export interface QuickMenuItem {
  id:       string;
  icon:     React.ReactNode;
  label:    string;
  onClick:  () => void;
  badge?:   number;             // 알림 배지 숫자
}

export interface QuickMenuGridProps {
  items:      QuickMenuItem[];
  cols?:      2 | 3 | 4;       // 기본: 4
  className?: string;
}

// ── SearchAccordion ───────────────────────────────────────────
export interface SearchAccordionProps {
  placeholder?: string;
  onSearch:     (query: string) => void;
  filters?:     React.ReactNode; // 펼쳐지는 필터 영역 슬롯
  className?:   string;
}
```

---

## 6. 확정된 도메인 설계 방침

> 이전 미결 항목이 모두 결정됨 (2026-03-26). 아래 방침은 개발 표준으로 확정.

---

### 6.1 계좌 카드 변형 (Account Card Variants) ✅ 확정

**방침**: `AccountSummaryCard` 단일 컴포넌트로 모든 계좌 유형 대응.

- `type` prop(`'deposit' | 'savings' | 'loan'`)으로 내부 요소 분기
- 금액은 `number`로 수신 → 컴포넌트 내부 `Intl.NumberFormat('ko-KR')` 처리
- `badgeText` prop 존재 시에만 배지 노출 (미전달 시 배지 영역 렌더링 안 함)

```typescript
export type AccountType = 'deposit' | 'savings' | 'loan';

export interface AccountSummaryCardProps {
  type:           AccountType;
  accountName:    string;          // 예: '급여 통장', '청약저축'
  accountNumber:  string;          // 예: '123-456-789012'
  balance:        number;          // 원화 단위 숫자. 내부 포맷: Intl.NumberFormat
  balanceLabel?:  string;          // 기본: '잔액' (대출은 '대출잔액' 등)
  badgeText?:     string;          // 미전달 시 배지 미노출
  onClick?:       () => void;
  actions?:       React.ReactNode; // 이체·내역 버튼 슬롯
  className?:     string;
}
```

**타입별 분기 기준**:

| `type` | 금액 레이블 기본값 | 배지 용도 예시 | 특이사항 |
|--------|--------------|-------------|---------|
| `deposit` | `'잔액'` | `'주거래'`, `'급여'` | 없음 |
| `savings` | `'납입금액'` | `'D-30'` (만기일) | 진행률 바 표시 가능 |
| `loan` | `'대출잔액'` | `'변동금리'` | 금액 색상 danger 계열 |

---

### 6.2 이체 폼 구조 (Transfer Form Structure) ✅ 확정

**방침**: 단일 페이지 폼(Single Page Form). Stepper 미사용.

- 입력 필드를 세로 `Stack`으로 나열, 이전 입력 완료 시 다음 필드 순차 활성화
- 최종 확인은 **페이지 이동 없이** `Modal` 또는 `BottomSheet`로 처리
  - 모바일(390px): `BottomSheet` 사용
  - 태블릿 이상: `Modal` 사용 (`size="md"`)

```
이체 화면 구조:
  PageLayout (title="이체하기")
  └─ Stack gap="lg"
      ├─ Input (받는 계좌)
      ├─ Input (금액) — 이전 필드 완료 후 활성화
      ├─ Input (메모, optional)
      └─ Button (이체하기) → BottomSheet / Modal 열기

확인 오버레이:
  BottomSheet | Modal
  ├─ 이체 요약 (CardRow × 3)
  └─ [취소] [이체 확인] 버튼 행
```

---

### 6.3 거래 내역 그룹핑 (Transaction Grouping) ✅ 확정

**방침**: 날짜별 스티키 그룹 헤더 상시 노출.

- 날짜 형식 표준: `YYYY.MM.DD` (예: `2026.03.26`)
- API 응답은 flat 배열. 프론트엔드에서 날짜별 객체 배열로 변환 후 렌더링

**데이터 변환 구조**:

```tsx
// API 응답 (flat)
interface TransactionItem {
  id:        string;
  date:      string;   // ISO 8601: '2026-03-26T14:30:00Z'
  title:     string;
  amount:    number;
  balance:   number;
  type:      'deposit' | 'withdrawal' | 'transfer';
}

// 프론트 변환 후 (grouped)
interface TransactionGroup {
  date:   string;             // 표시용 'YYYY.MM.DD'
  items:  TransactionItem[];
}

// 렌더링 패턴
transactionGroups.map(group => (
  <section key={group.date}>
    <p className="text-xs text-text-muted sticky top-0 bg-surface py-xs px-standard">
      {group.date}
    </p>
    {group.items.map(item => <TransactionListItem key={item.id} {...item} />)}
  </section>
))
```

---

### 6.4 홈 배너 슬라이더 (Home Banner Slider) ✅ 확정

**방침**: 단일 배너 / 멀티 캐러셀 가변 대응. 데이터 수에 따라 동작 자동 결정.

| 배너 수 | 인디케이터 | 자동 재생 | 스와이프 |
|--------|---------|---------|--------|
| 1개 | 비활성화 (미노출) | 비활성화 | 비활성화 |
| 2개 이상 | 활성화 | 활성화 (3초 간격) | 활성화 |

```typescript
// BannerCarousel — 신규 제안 (biz/)
export interface BannerCarouselItem {
  id:           string;
  variant?:     BannerVariant;   // 기본: 'promo'
  title:        string;
  description?: string;
  action?:      React.ReactNode;
  onClose?:     () => void;
}

export interface BannerCarouselProps {
  items:           BannerCarouselItem[];
  /** 자동 재생 간격(ms). 기본: 3000. items.length < 2이면 무시 */
  autoPlayInterval?: number;
  className?:      string;
}
```

---

### 6.5 빈 상태 화면 (Empty State) ✅ 확정

**방침**: `EmptyState` 공통 컴포넌트 사용. 도메인별 콘텐츠는 props로 주입.

- 컴포넌트 자체는 브랜드·도메인 무관 (`modules/`)
- `illustration`, `title`, `description`, `action`을 외부에서 주입하여 도메인별 교체

```typescript
// EmptyState — modules/ (기존 컴포넌트 인터페이스 확인 후 갱신)
export interface EmptyStateProps {
  /** SVG 또는 img 요소. 도메인별 일러스트 주입 */
  illustration?: React.ReactNode;
  title:         string;
  description?:  string;
  /** CTA 버튼 등 액션 슬롯 */
  action?:       React.ReactNode;
  className?:    string;
}
```

**도메인별 사용 예시**:

```tsx
// 계좌 없음
<EmptyState
  illustration={<AccountEmptyIllust />}
  title="등록된 계좌가 없어요"
  description="계좌를 추가하면 잔액과 거래 내역을 확인할 수 있어요"
  action={<Button onClick={onAddAccount}>계좌 추가하기</Button>}
/>

// 거래 내역 없음
<EmptyState
  illustration={<TransactionEmptyIllust />}
  title="거래 내역이 없어요"
/>
```

---

### 6.6 확정된 개발 표준

이전 결정 미정 항목들의 최종 확정값:

| 항목 | 확정 방침 |
|-----|---------|
| **금액 포맷팅** | 컴포넌트 내부 `Intl.NumberFormat('ko-KR')` 처리. 외부에서 `number` 타입으로 전달 |
| **날짜 포맷** | 네이티브 `Intl.DateTimeFormat` 사용. `date-fns` 미도입 (의존성 최소화) |
| **에러 상태 관리** | 상위 훅(`useFormValidation`)에서 통합 처리 후 컴포넌트에 `validationState` prop 전달 |
| **아이콘 라이브러리** | `lucide-react` 단일 사용 유지. Material Symbols 혼용 금지 |

---

### 6.7 신규 생성 컴포넌트 목록 (확정)

| 컴포넌트명 | 분류 | 우선순위 | 비고 |
|----------|------|---------|-----|
| `AccountSummaryCard` | biz/ | 높음 | §6.1 설계 확정 |
| `AccountSelectorCard` | biz/ | 높음 | §6.8 설계 확정. AccountSummaryCard와 역할 구분 |
| `TransactionListItem` | biz/ | 높음 | §6.3 그룹핑 패턴 연동 |
| `BannerCarousel` | biz/ | 높음 | §6.4 슬라이더 로직 포함 |
| `AmountInput` | modules/ | 높음 | 이체 폼 핵심. `Intl` 실시간 포맷 |
| `TransactionSearchFilter` | modules/ | 높음 | §6.9 설계 확정. 거래내역 조회 조건 필터 |
| `AppBrandHeader` | layout/ | 높음 | §6.10 설계 확정. 로그인·온보딩 화면 브랜드 로고 헤더 |
| `DividerWithLabel` | modules/ | 높음 | §6.11 설계 확정. 텍스트 중앙 구분선 |
| `SectionHeader` | modules/ | 중간 | 타이틀+액션 3회 이상 반복 패턴 |
| `OtpInput` | modules/ | 중간 | 6자리 PIN 입력 전용 |
| `QuickMenuGrid` | biz/ | 중간 | 홈 퀵메뉴 2×N 그리드 |
| `TransferStepper` | biz/ | 낮음 | 단일 폼 방침 확정으로 우선순위 하향 |

---

### 6.8 계좌 선택 카드 (Account Selector Card) ✅ 확정

**방침**: 잔액을 표시하지 않고 계좌를 선택·변경하는 전용 카드. `AccountSummaryCard`와 역할이 다르므로 별도 컴포넌트로 분리.

**AccountSummaryCard vs AccountSelectorCard 사용 기준**:

| 구분 | `AccountSummaryCard` | `AccountSelectorCard` |
|-----|---------------------|----------------------|
| 주요 사용처 | 홈, 계좌 목록 | 거래내역 조회, 이체 등 상세 화면 |
| 잔액 표시 | ✅ 필수 (`balance: number`) | ❌ 없음 |
| 계좌 변경 | ❌ | ✅ `onAccountChange` 드롭다운 |
| 우측 아이콘 버튼 | ❌ | ✅ `onIconClick` |
| 모서리 반경 | `rounded-xl` (12px) | `rounded-3xl` (24px, Figma 기준) |

```typescript
// AccountSelectorCard — biz/
export interface AccountSelectorCardProps {
  accountName:      string;            // 예: '하나 주거래 통장'
  accountNumber:    string;            // 예: '123-456-789012'. 마스킹 없이 표시
  icon?:            React.ReactNode;   // 우측 원형 버튼 아이콘. 기본: Landmark
  /** 계좌명 클릭 시 콜백. 미전달 시 드롭다운 화살표 숨김 */
  onAccountChange?: () => void;
  /** 우측 원형 아이콘 버튼 클릭 시 콜백 */
  onIconClick?:     () => void;
  className?:       string;
}
```

**사용 예시**:

```tsx
<AccountSelectorCard
  accountName="하나 주거래 통장"
  accountNumber="123-456-789012"
  onAccountChange={handleOpenAccountPicker}  // BottomSheet 등으로 계좌 변경
  onIconClick={handleGoToAccountDetail}
/>
```

---

### 6.9 거래내역 검색 필터 (Transaction Search Filter) ✅ 확정

**방침**: 접기/펼치기 아코디언 구조. 폼 내부 상태를 독립 관리하며 조회 버튼 클릭 시에만 `onSearch` 호출.

- 퀵 기간 탭(1·3·6·12개월) 선택 시 오늘 기준으로 `startDate`·`endDate` 자동 계산
- 날짜 직접 선택 시 `DatePicker` 컴포넌트 사용. 퀵 탭 선택 해제
- 정렬 순서(`최근순` / `과거순`), 거래 유형(`전체` / `입금` / `출금`) 드롭다운 제공
- 날짜 상태는 ISO string(`YYYY-MM-DD`)으로 관리. `DatePicker` 전달 시 `isoToDate()`로 변환
  - `T00:00:00` 로컬 시간으로 파싱해 시간대 오프셋으로 날짜가 밀리는 것 방지

```typescript
// TransactionSearchFilter — modules/
export type QuickPeriod    = '1m' | '3m' | '6m' | '12m';
export type SortOrder      = 'recent' | 'old';
export type TransactionType = 'all' | 'deposit' | 'withdrawal';

export interface TransactionSearchParams {
  startDate:       string;           // ISO 'YYYY-MM-DD'
  endDate:         string;           // ISO 'YYYY-MM-DD'
  sortOrder:       SortOrder;
  transactionType: TransactionType;
}

export interface TransactionSearchFilterProps {
  /** 현재 적용된 검색 조건. 초기값 및 외부 동기화에 사용 */
  value:            TransactionSearchParams;
  /** 조회 버튼 클릭 시 호출. 폼 내부 상태 기준으로 전달 */
  onSearch:         (params: TransactionSearchParams) => void;
  defaultExpanded?: boolean;         // 기본: false (접힌 상태)
  className?:       string;
}
```

**사용 예시**:

```tsx
const [searchParams, setSearchParams] = useState<TransactionSearchParams>({
  startDate: '2023-10-01',
  endDate:   '2023-11-01',
  sortOrder: 'recent',
  transactionType: 'all',
});

<TransactionSearchFilter
  value={searchParams}
  onSearch={setSearchParams}  // 조회 버튼 클릭 시에만 상태 갱신
/>
```

---

---

### 6.10 앱 브랜드 헤더 (App Brand Header) ✅ 확정

**방침**: 로그인·온보딩 화면(`BlankPageLayout`) 최상단에 배치하는 브랜드 로고 전용 헤더.
`PageLayout`의 헤더(뒤로가기 + 타이틀 구조)와 역할이 다르므로 별도 컴포넌트로 분리.

**PageLayout 헤더 vs AppBrandHeader 사용 기준**:

| 구분 | `PageLayout` 헤더 | `AppBrandHeader` |
|-----|-----------------|-----------------|
| 사용처 | 계좌 목록·상세, 이체 폼 등 일반 페이지 | 로그인·온보딩 화면 |
| 레이아웃 | 뒤로가기(좌) + 타이틀(중앙) + 액션(우) | 브랜드 이니셜 배지 + 브랜드명 중앙 정렬 |
| 네비게이션 | ✅ 뒤로가기 버튼 포함 | ❌ 네비게이션 없음 |

```typescript
// AppBrandHeader — layout/
export interface AppBrandHeaderProps {
  /** 브랜드 이니셜 — 원형 배지 내부 표시 (예: 'H') */
  brandInitial: string;
  /** 브랜드명 (예: '하나은행') */
  brandName:    string;
  className?:   string;
}
```

**사용 예시**:

```tsx
<BlankPageLayout>
  <AppBrandHeader brandInitial="H" brandName="하나은행" />
  {/* 로그인 폼 콘텐츠 */}
</BlankPageLayout>
```

---

### 6.11 텍스트 레이블 구분선 (Divider With Label) ✅ 확정

**방침**: 좌우 수평선 + 중앙 텍스트로 구성된 섹션 구분선.
로그인 화면 "다른 로그인 방식"처럼 두 영역의 시각적 경계를 표시할 때 사용.

```typescript
// DividerWithLabel — modules/
export interface DividerWithLabelProps {
  /** 구분선 중앙에 표시할 텍스트 (예: '다른 로그인 방식', '또는') */
  label:      string;
  className?: string;
}
```

**사용 예시**:

```tsx
<DividerWithLabel label="다른 로그인 방식" />
```

---

### 6.12 로그인 페이지 구성 방침 ✅ 확정

**Figma 원본**: Hana Bank App — node-id: 1-911

**컴포넌트 조합**:

```
BlankPageLayout
├─ AppBrandHeader          brandInitial="H" brandName="하나은행"
├─ Stack (flex-1, px-standard)
│   ├─ Stack gap="xs"      타이틀 섹션
│   │   ├─ Text as="h1" variant="heading" className="text-3xl"   → "로그인"
│   │   └─ Text variant="body" color="muted"                     → 부제목
│   ├─ Stack gap="lg"      입력 폼
│   │   ├─ Input label="아이디" type="text" fullWidth
│   │   └─ Input label="비밀번호" type="password" validationState="error"
│   │             helperText="..." rightElement={<EyeOff />} fullWidth
│   ├─ Inline justify="center"  텍스트 링크 행
│   │   ├─ Button variant="ghost" size="sm"   → 아이디 찾기
│   │   ├─ (수직 구분선 div)
│   │   ├─ Button variant="ghost" size="sm"   → 비밀번호 변경
│   │   ├─ (수직 구분선 div)
│   │   └─ Button variant="ghost" size="sm"   → 회원가입
│   └─ Button variant="primary" size="lg" fullWidth  → 로그인
└─ Stack (px-standard, pb-2xl)  대체 로그인
    ├─ DividerWithLabel label="다른 로그인 방식"
    └─ QuickMenuGrid cols={3}   간편 비밀번호 / 생체인증 / QR 로그인
```

**타이틀 크기 처리**:
- Figma 원본: 30px. `Text` `heading` variant는 `text-2xl`(24px)
- `className="text-3xl"` override로 30px 재현 (`text-3xl` = Tailwind 표준 30px)

---

---

### 6.13 홈 대시보드 페이지 구성 방침 ✅ 확정

**Figma 원본**:
- 해당금융 탭: Hana Bank App — node-id: 1-202
- 다른금융 탭: Hana Bank App — node-id: 1-336

**신규 컴포넌트 없이** 기존 컴포넌트 100% 조합으로 구현 가능.

**탭별 콘텐츠 분기**:

| 탭 | 주요 컴포넌트 | 특이사항 |
|----|-------------|---------|
| 해당금융 | `AccountSummaryCard` + 소형 연결 유도 `Card` | `Card className="bg-brand-5 border-brand-10 rounded-3xl"` |
| 다른금융 | `Card` + `EmptyState` + `Button` | `Card className="border-dashed bg-surface-raised"` |
| 자산관리 | 미구현 — `EmptyState` 플레이스홀더 | 추후 Figma 제공 시 구현 |

**공통 영역** (모든 탭):
- `QuickMenuGrid cols={3}` — 전계좌조회·이체·내역조회
- `BannerCarousel variant="promo"` — 프로모션 배너
- `SectionHeader` + `NoticeItem × 3` — 공지 및 혜택

**컴포넌트 조합**:

```
HomePageLayout
  title="Hana Bank"  logo={<Building2 />}  hasNotification  withBottomNav
├─ Text as="h2" variant="heading"    → "안녕하세요, 김하나님!"  {/* greeting prop 제거 → 본문 내 직접 표시 */}
├─ TabNav                            → 해당금융 / 다른금융 / 자산관리
├─ Stack gap="md" px-standard
│   ├─ [mine]  AccountSummaryCard    → 계좌 카드
│   │          Card (brand-5, dashed border, rounded-3xl)  → 연결 유도 소형 배너
│   ├─ [other] Card (border-dashed)
│   │          └─ EmptyState + Button  → 계좌 미연결 빈상태
│   ├─ [asset] EmptyState            → 미구현 플레이스홀더
│   ├─ QuickMenuGrid cols={3}        → 퀵 액션 그리드
│   ├─ BannerCarousel                → 프로모션 배너
│   └─ SectionHeader + NoticeItem×3  → 공지 및 혜택
└─ BottomNav activeId="home"         → 하단 고정 탭바
```

**헤더 기본 rightAction** (User·Bell·Menu 3버튼 내장):
- `hasNotification={true}` 전달 시 벨 아이콘 우측 상단에 `bg-danger-badge` 빨간 뱃지 자동 표시
- 커스텀 우측 영역이 필요한 경우 `rightAction` prop으로 직접 전달

```tsx
{/* 기본 사용 — 알림 뱃지 있음 */}
<HomePageLayout title="Hana Bank" logo={<HanaLogo />} hasNotification withBottomNav>
  ...
</HomePageLayout>

{/* rightAction 커스텀 override */}
<HomePageLayout title="Hana Bank" rightAction={<MyCustomActions />} withBottomNav>
  ...
</HomePageLayout>
```

---

*모든 미결 항목 해소 완료 — 2026-03-27*

*본 문서는 Figma 디자인 열람 및 개발 진행에 따라 지속적으로 업데이트됩니다.*
